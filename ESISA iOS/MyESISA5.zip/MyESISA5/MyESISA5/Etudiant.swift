//
//  Etudiant.swift
//  RESful API
//
//  Created by Mohamed Sneiba on 4/15/18.
//  Copyright © 2018 Mohamed Sneiba. All rights reserved.
//

import Foundation


class Etudiant {
    
    var id:Int!
    var nom:String!
    var prenom:String!
    var lieuNaissance:String!
    var numInscription:String!
    var CIN:String!
    var adresse:String!
    var teldom:String!
    var tel:String!
    var telpere:String!
    var telmere:String!
    var an:Int!
    var mn:Int!
    var jn:Int!
    var ai:Int!
    var mi:Int!
    var ji:Int!
    
    init() {
        
    }
    
    
}
