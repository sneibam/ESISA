//
//  CollectionViewCell.swift
//  MyESISA5
//
//  Created by HARCHLI Chaymae on 25/05/2018.
//  Copyright © 2018 HARCHLI Chaymae. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
   
    @IBOutlet weak var iconsImageView: UIImageView!
    @IBOutlet weak var iconLabel: UILabel!
}
